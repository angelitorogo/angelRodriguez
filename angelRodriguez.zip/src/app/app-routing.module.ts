import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './shared/pages/home/home.component';
import { LeerMasComponent } from './shared/pages/leer-mas/leer-mas.component';
import { TermsConditionsComponent } from './shared/pages/terms-conditions/terms-conditions.component';
import { FaqComponent } from './shared/pages/faq/faq.component';


const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent
  },
  {
    path: 'more',
    component: LeerMasComponent
  },
  {
    path: 'terms-conditions',
    component: TermsConditionsComponent
  },
  {
    path: 'faqs',
    component: FaqComponent
  },
  {
    path: 'auth',
    loadChildren: () => import('./auth/auth.module').then( m => m.AuthModule),
  },
  {
    path: 'surveis',
    loadChildren: () => import('./encuestas/encuestas.module').then( m => m.EncuestasModule),
  },
  {
    path: 'dashboard',
    loadChildren: () => import('./dashboard/dashboard.module').then( m => m.DashboardModule),
  },
  {
    path: 'response',
    loadChildren: () => import('./answered/answered.module').then( m => m.AnsweredModule),
  },
  {
    path:'**',
    redirectTo: 'home'
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes, {
    useHash: true,
    anchorScrolling: 'enabled',
    scrollPositionRestoration: 'enabled'
  })],
  exports: [RouterModule]
})
export class AppRoutingModule { }
