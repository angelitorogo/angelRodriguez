import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { SharedModule } from '../shared/shared.module';
import { Modal1Component } from '../shared/components/modal1/modal1.component';
import { Boton6Component } from '../shared/components/boton6/boton6.component';
import { EncuestaComponent } from './components/encuesta/encuesta.component';
import { EncuestasComponent } from './components/encuestas/encuestas.component';
import { FormsModule } from '@angular/forms';
import { ResultsComponent } from './components/results/results.component';
import { PublishComponent } from './components/publish/publish.component';
import { NgxChartsModule } from '@swimlane/ngx-charts';


@NgModule({
  declarations: [
    DashboardComponent,
    EncuestaComponent,
    EncuestasComponent,
    ResultsComponent,
    PublishComponent
  ],
  imports: [
    CommonModule,
    DashboardRoutingModule,
    FormsModule,
    SharedModule,
    Modal1Component,
    Boton6Component,
    NgxChartsModule,
  ]
})
export class DashboardModule { }
