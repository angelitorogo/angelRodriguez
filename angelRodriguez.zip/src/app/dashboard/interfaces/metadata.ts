export interface Metadata {
    totalEncuestas: number;
    page: number;
    lastPage: number;
  }

  export interface MetadataResponse {
    totalEncuestasRespondidas: number;
    page: number;
    lastPage: number;
  }