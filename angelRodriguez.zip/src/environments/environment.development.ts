export const environment = {
    API_URL: 'https://auth.argomez.com/api',
    DOMAIN_URL: 'http://localhost:4200/',
    //DOMAIN_URL: 'https://formuease.argomez.com/'
    APP_NAME: 'Formuease dev'
};
